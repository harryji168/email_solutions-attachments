<?php

namespace App\Cells;

use CodeIgniter\View\Cells\Cell;
use App\Models\Partner\VideoModel;

class FeaturedVideoCell extends Cell
{
    
    protected $item;
    protected string $view = 'featured_template';
    
    public function mount() {

        $videoModel = new VideoModel();
        $video = $videoModel->fetchFeaturedVideo();

        $item['title'] = "FEATURED VIDEO";
        $item['href'] = base_url('videos/' . urlParameterAddHyphen($video['company_name']) . '/' . $video['meta_file_name']);
        $item['img-alt'] = $video['headline'];
        $item['img-source'] = base_url("uploads/videos/" . $video['thumbnail_img']);
        $item['company-name'] = $video['company_name'];
        $item['company-text'] = $video['headline'];
        $item['search-href'] = base_url('videos');
        $item['search-text'] = 'Search Electrical Videos';
        $item['isVideo'] = true;

        /* Going to have to revisit how this data tracking works. This is quite a bit of data to store just for viewing thumbnails
        if (isset($sessionData['sess_user_id'])) {
            $visitorModel->visitorStatDatabase($videoChannelId, $videoCompanyId, $videoId, "video", $sessUserId, $videoUrl);
        } else {
            $visitorModel->visitorStatDatabase($videoChannelId, $videoCompanyId, $videoId, "video", 0, $videoUrl);
        }*/

        $this->item = $item;

    }

    public function getItemProperty() {
        return $this->item;
    } 

}
