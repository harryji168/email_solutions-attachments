<?php

namespace App\Cells;

use CodeIgniter\View\Cells\Cell;
use App\Models\Partner\ShowcaseModel;

class FeaturedShowcaseCell extends Cell
{
    
    protected $item;
    protected string $view = 'featured_template';
    
    public function mount() {

        $showcaseModel = new ShowcaseModel();
        $showcase = $showcaseModel->fetchFeaturedShowcase();

        $item['title'] = "POPULAR SHOWCASE";
        $item['href'] = base_url('showcases/' . urlParameterAddHyphen($showcase['company_name']) . '/' . $showcase['meta_file_name']);
        $item['img-alt'] = $showcase['company_name'];
        $item['img-source'] = base_url("uploads/showcases/" . $showcase['product_image']);
        $item['company-name'] = $showcase['company_name'];
        $item['company-text'] = $showcase['headline'];
        $item['search-href'] = base_url('showcases');
        $item['search-text'] = 'Search Showcases';

        /* DISABLED FOR NOW - WILL NEED TO ADJUST LATER with Session Variables
        if (isset($sessionData['sess_user_id'])) {
            $visitorModel->visitorStatDatabase($showcase['primary_channel_id'],$showcase['company_account_id'],$showcase['id'],"showcase",$sess_user_id,$showcaseUrl);
        } else {
            $visitorModel->visitorStatDatabase($showcaseChannelId,$showcaseCompanyId,$showcaseId,"showcase",0,$showcaseUrl);
            $visitorModel->visitorStatDatabase($showcase['primary_channel_id'],$showcase['company_account_id'],$showcase['id'],"showcase",0,$showcaseUrl);
        } 
        */

        $this->item = $item;

    }

    public function getItemProperty() {
        return $this->item;
    }   

}
