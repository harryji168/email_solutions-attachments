<?php

namespace App\Cells;

use CodeIgniter\View\Cells\Cell;
use App\Models\Partner\LiteratureModel;

class LatestLiteratureCell extends Cell
{
    
    protected $content;
    protected $items;

    protected string $view = 'latest_template';
    
    public function mount() {

        // Process Static Content
        $content = [];
        $content['header-light'] = "Latest ";
        $content['header-bold'] = "Literature for Download";

        // Process Database Content
        $itemModel = new LiteratureModel();
        $items = $itemModel->fetchLatestLiterature();

        if( !empty($items) && is_array($items) ) {
            foreach( $items as $key => $item ) {
                $items[$key]['href'] = base_url('catalog/') . url_title($item['companyName'], 'dash', TRUE) . '/' . $item['meta_file_name'];
                $items[$key]['img-source'] = base_url("uploads/catalogs/") . $item['upload_thumb_image'];
                $items[$key]['img-alt'] = 'Literature Thumbnail';
                $items[$key]['text'] = $item['headline'];
            }
        }

        /* REVISIT VISITOR TRACKING METHODS
        if (isset($sessionData['sess_user_id'])) {
            $visitorModel->visitorStatDatabase($catalogChannelId, $catalogCompanyId, $catalogId, "catalog", $sessUserId, $urlCatalog);
        } else {
            $visitorModel->visitorStatDatabase($catalogChannelId, $catalogCompanyId, $catalogId, "catalog", 0, $urlCatalog);
        }
        */

        $this->items = $items;
        $this->content = $content;

    }

    public function getItemsProperty() {
        return $this->items;
    }

    public function getContentProperty() {
        return $this->content;
    }  

}
