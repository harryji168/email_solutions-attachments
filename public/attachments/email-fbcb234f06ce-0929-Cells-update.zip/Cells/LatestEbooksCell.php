<?php

namespace App\Cells;

use CodeIgniter\View\Cells\Cell;
use App\Models\Partner\EbookModel;

class LatestEbooksCell extends Cell
{
    
    protected $content;
    protected $items;

    protected string $view = 'latest_template';
    
    public function mount() {

        // Process Static Content
        $content = [];
        $content['header-light'] = "Latest ";
        $content['header-bold'] = "E-BOOKS";

        // Process Database Content
        $itemModel = new EbookModel();
        $items = $itemModel->fetchHandbooks();

        if( !empty($items) && is_array($items) ) {
            foreach( $items as $key => $item ) {
                $items[$key]['href'] = base_url('catalog/' . urlParameterAddHyphen($item['company_name']) . '/' . $item['meta_file_name']);
                $items[$key]['img-source'] = base_url("uploads/catalogs/" . $item['upload_thumb_image']);
                $items[$key]['img-alt'] = 'Ebook Thumbnail';
                $items[$key]['text'] = $item['headline'];
            }
        }

        $this->items = $items;
        $this->content = $content;

    }

    public function getItemsProperty() {
        return $this->items;
    }

    public function getContentProperty() {
        return $this->content;
    }

}
