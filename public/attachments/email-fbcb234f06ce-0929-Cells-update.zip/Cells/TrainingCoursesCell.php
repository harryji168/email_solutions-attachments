<?php

namespace App\Cells;

use CodeIgniter\View\Cells\Cell;
use App\Models\Training\CourseModel;

class TrainingCoursesCell extends Cell
{
    
    protected $courseSet;
    
    public function mount() {

        $coursesModel = new CourseModel();
        $currentDate = new \DateTime();

        $dataSet = [];

        for( $i = 0; $i < 4; $i++ ) {

            $month = (int)$currentDate->format('m');
            $year = (int)$currentDate->format('Y');
            $courseItem = $coursesModel->fetchCoursesByMonthYear( $month, $year );

            array_push($dataSet, [
                'month' => $month,
                'year' => $year,
                'courses' => $courseItem
            ]);

            $currentDate->modify('+1 month');
        }

        $this->courseSet = $dataSet;

    }

    public function getCourseSetProperty() {
        return $this->courseSet;
    }   

}
