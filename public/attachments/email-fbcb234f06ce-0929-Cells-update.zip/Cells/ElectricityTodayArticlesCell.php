<?php

namespace App\Cells;

use CodeIgniter\View\Cells\Cell;
use App\Models\Content\ElectricityTodayModel;

class ElectricityTodayArticlesCell extends Cell
{
    
    protected $content;
    protected $items;

    protected string $view = 'latest_template';
    
    public function mount() {

        $etModel = new ElectricityTodayModel();

        $etarticles = $etModel->fetchArticles();

        $this->etarticles = $etarticles;

        // Process Static Content
        $content = [];
        $content['header-light'] = "Latest ";
        $content['header-bold'] = "Electricity Today T&D Articles";

        // Process Database Content
        $itemModel = new ElectricityTodayModel();
        $items = $itemModel->fetchArticles();

        if( !empty($items) && is_array($items) ) {
            foreach( $items as $key => $item ) {
                $items[$key]['href'] = $item['link'];
                $items[$key]['img-source'] = $item['image'];
                $items[$key]['img-alt'] = 'Article Thumbnail';
                $items[$key]['text'] = $item['title'];
            }
        }

        $this->items = $items;
        $this->content = $content;

    }

    public function getItemsProperty() {
        return $this->items;
    }

    public function getContentProperty() {
        return $this->content;
    }  

}
