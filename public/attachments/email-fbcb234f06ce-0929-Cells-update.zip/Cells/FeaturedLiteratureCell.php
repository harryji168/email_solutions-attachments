<?php

namespace App\Cells;

use CodeIgniter\View\Cells\Cell;
use App\Models\Partner\LiteratureModel;

class FeaturedLiteratureCell extends Cell
{
    
    protected $item;
    protected string $view = 'featured_template';
    
    public function mount() {

        $literatureModel = new LiteratureModel();
        $literature = $literatureModel->fetchFeaturedLiterature();

        $item['title'] = "FREE LITERATURE";
        $item['href'] = base_url('catalog/') . urlParameteraddHyphen($literature['company_name1']) . '/' . $literature['meta_file_name'];
        $item['img-alt'] = $literature['headline'];
        $item['img-source'] = base_url("uploads/catalogs/" . $literature['upload_thumb_image']);
        $item['company-name'] = $literature['company_name1'];
        $item['company-text'] = $literature['headline'];
        $item['search-href'] = base_url('literature');
        $item['search-text'] = 'Search Downloads';

        /* Going to have to revisit how this data tracking works. This is quite a bit of data to store just for viewing thumbnails
        if (isset($sessionData['sess_user_id'])) {
            $visitorModel->visitorStatDatabase($catalogChannelId,$catalogCompanyId,$catalogId,"catalog",$sess_user_id,$urlCatalog);
        }else{
            $visitorModel->visitorStatDatabase($catalogChannelId,$catalogCompanyId,$catalogId,"catalog",0,$urlCatalog);
        }
        */

        $this->item = $item;

    }

    public function getItemProperty() {
        return $this->item;
    }   

}
