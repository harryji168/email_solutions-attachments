<div class="text-left">
	<h5 class="heading51 text-left">
		<span class="header-light"><?=$content['header-light'];?> </span>
		<span class="header-bold"><?=$content['header-bold'];?></span>
	</h5>
</div>

<div class="col-md-12 no-pad-left no-pad-right" style="overflow:hidden;">
	<?php foreach( $items as $item ):?>
		<div class="col-sm-3 col-xs-6 margin_top10 no-pad-left">

				<a href="<?=$item['href'];?>">

					<img width="112" height="92" loading="lazy" style="object-fit:cover;padding:0;" class="module-block video-thumb text-center" src="<?=$item['img-source'];?>" alt="<?=$item['img-alt'];?>" />

					<div class="caption" style="height:80px;">
						<p style="padding:3px 0px;font-size:11px;font-weight:400;"><?=$item['text']?></p>
					</div>

				</a>
		</div>
	<?php endforeach;?>
</div>