<?php

namespace App\Cells;

use CodeIgniter\View\Cells\Cell;
use App\Models\Content\WebinarModel;

class UpcomingWebinarsCell extends Cell
{
    
    protected $content;
    protected $items;

    protected string $view = 'latest_template';

    public function mount() {

        // Process Static Content
        $content = [];
        $content['header-light'] = "UPCOMING ";
        $content['header-bold'] = "Webinars ";

        // Process Database Content
        $itemModel = new WebinarModel();
        $items = $itemModel->fetchUpcomingWebinars();

        if( !empty($items) && is_array($items) ) {
            foreach( $items as $key => $item ) {
                if (date_create($item['end_date']) > date_create() && $item['start_date'] !== '0000-00-00') {
                    $items[$key]['href'] = $item['code'];
                } else {
                    $items[$key]['href'] = base_url('webinars/' . $item['ca_meta_file_name'] . '/' . $item['meta_file_name']);
                }
                $items[$key]['img-source'] = base_url('uploads/videos/' . $item['thumbnail_img']);
                $items[$key]['img-alt'] = 'Webinar Thumbnail';
                $items[$key]['text'] = $item['headline'];
            }
        }

        /* WRITES TO VISITOR DATABASE - AS BELOW - REVIEW NECESSITY FOR THIS
        if (isset($sessionData['sess_user_id'])) {
            $visitorModel->visitorStatDatabase($webinarChannelId,$webinarCompanyId,$webinarId,"webinar",$sess_user_id,$webinarUrl);
        } else {
            $visitorModel->visitorStatDatabase($webinarChannelId,$webinarCompanyId,$webinarId,"webinar",0,$webinarUrl);
        }   
        */

        $this->items = $items;
        $this->content = $content;

    }

    public function getItemsProperty() {
        return $this->items;
    }

    public function getContentProperty() {
        return $this->content;
    }

}
