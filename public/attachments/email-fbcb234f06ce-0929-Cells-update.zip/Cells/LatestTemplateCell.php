<?php

namespace App\Cells;

use CodeIgniter\View\Cells\Cell;

class LatestTemplateCell extends Cell
{
    
    protected $content;
    protected $items;
    
    public function mount( $section = null ) {

        if( $section == null ) return;

        switch( $section ) {
            case 'webinars' :
                $container = $this->processWebinars();
                break;
            case 'videos' :
                $container = $this->processVideos();
                break;
        }

        $this->items = $container['items'];
        $this->content = $container['content'];

    }

    public function getItemsProperty() {

        return $this->items;

    }

    public function getContentProperty() {

        $content = [];
        $content['header-light'] = "UPCOMING ";
        $content['header-bold'] = "Webinars ";

        return $content;
    }

    private function processWebinars() {

        $container = [];

        // Process Static Content
        $content = [];
        $content['header-light'] = "UPCOMING ";
        $content['header-bold'] = "Webinars ";

        // Process Database Content
        $itemModel = new \App\Models\Content\WebinarModel();
        $items = $itemModel->fetchUpcomingWebinars();

        if( !empty($items) && is_array($items) ) {
            foreach( $items as $key => $item ) {
                if (date_create($item['end_date']) > date_create() && $item['start_date'] !== '0000-00-00') {
                    $items[$key]['href'] = $item['code'];
                } else {
                    $items[$key]['href'] = base_url('webinars/' . $item['ca_meta_file_name'] . '/' . $item['meta_file_name']);
                }
                $items[$key]['img-source'] = base_url('uploads/videos/' . $item['thumbnail_img']);
                $items[$key]['img-alt'] = 'Webinar Thumbnail';
                $items[$key]['text'] = $item['headline'];
            }
        }

        // Populate Container
        $container['items'] = $items;
        $container['content'] = $content;

        /* WRITES TO VISITOR DATABASE - AS BELOW - REVIEW NECESSITY FOR THIS
        if (isset($sessionData['sess_user_id'])) {
            $visitorModel->visitorStatDatabase($webinarChannelId,$webinarCompanyId,$webinarId,"webinar",$sess_user_id,$webinarUrl);
        } else {
            $visitorModel->visitorStatDatabase($webinarChannelId,$webinarCompanyId,$webinarId,"webinar",0,$webinarUrl);
        }   
        */

        return $container;

    }

    private function processVideos() {

        $container = [];

        // Process Static Content
        $content = [];
        $content['header-light'] = "UPCOMING ";
        $content['header-bold'] = "Webinars ";

        // Process Database Content
        $itemModel = new \App\Models\Content\WebinarModel();
        $items = $itemModel->fetchUpcomingWebinars();

        if( !empty($items) && is_array($items) ) {
            foreach( $items as $key => $item ) {
                if (date_create($item['end_date']) > date_create() && $item['start_date'] !== '0000-00-00') {
                    $items[$key]['href'] = $item['code'];
                } else {
                    $items[$key]['href'] = base_url('webinars/' . $item['ca_meta_file_name'] . '/' . $item['meta_file_name']);
                }
                $items[$key]['img-source'] = base_url('uploads/videos/' . $item['thumbnail_img']);
                $items[$key]['img-alt'] = 'Webinar Thumbnail';
                $items[$key]['text'] = $item['headline'];
            }
        }

        // Populate Container
        $container['items'] = $items;
        $container['content'] = $content;

        /* WRITES TO VISITOR DATABASE - AS BELOW - REVIEW NECESSITY FOR THIS
        if (isset($sessionData['sess_user_id'])) {
            $visitorModel->visitorStatDatabase($webinarChannelId,$webinarCompanyId,$webinarId,"webinar",$sess_user_id,$webinarUrl);
        } else {
            $visitorModel->visitorStatDatabase($webinarChannelId,$webinarCompanyId,$webinarId,"webinar",0,$webinarUrl);
        }   
        */

        return $container;

    }

}
