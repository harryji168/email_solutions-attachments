<div id="courses-home">
        
	<div>
		<!-- REALLY gotta redesign this all. inline css like this is unacceptable -->
		<div class="col-md-4 col-xs-4 no-pad-left">
			<div style="background-color: #f69c55; border-radius: 50%; border: 0;background-size: 70%;background-image: url(images/training-icon-transparent.png);min-height:55px;width:55px;background-repeat:no-repeat;background-position:center;"></div>
		</div>

		<div class="col-md-8 col-xs-8 no-pad-right no-pad-left">
			<h4 class="heading6 close-up">
				<span style="font-weight:700;font-size:18px;">LIVE ONLINE ELECTRICAL TRAINING SCHEDULE</span>
			</h4>
		</div>

		<div class="clear"></div>
	</div>

	<div class="text-left push-down">
		<?php foreach ($courseSet as $item): ?>
			<div class="margin_top10">
				<h7 class="smallcaps">
					<?=DateTime::createFromFormat('!m', $item['month'])->format('M') . ', ' . DateTime::createFromFormat('!Y', $item['year'])->format('Y');?>
				</h7>
			</div>

			<?php if( !empty($item['courses']) ):?>
				<?php foreach( $item['courses'] as $course ):?>

					<div class="margin_top10">
						<div class="download-title courses_section">
							<a class="dark-link" href="<?=$course['courseURL']?>"><?= $course['headline'];?></a>
						</div>
					</div>

				<?php endforeach; ?>
			<?php else: ?>
				<p>No courses available.</p>
			<?php endif; ?>
		<?php endforeach; ?>
	</div>

</div>