<?php

namespace App\Cells;

use CodeIgniter\View\Cells\Cell;
use App\Models\Partner\EbookModel;

class FeaturedEbookCell extends Cell
{
    
    protected $item;
    protected string $view = 'featured_template';
    
    public function mount() {

        $ebookModel = new EbookModel();
        $ebook = $ebookModel->fetchMustHaveEBook();

        $item['title'] = "'MUST-HAVE' E-BOOK";
        $item['href'] = base_url('catalog/' . urlParameterAddHyphen($ebook['company_name']) . '/' . $ebook['meta_file_name']);
        $item['img-alt'] = $ebook['headline'];
        $item['img-source'] = base_url("uploads/catalogs/" . $ebook['upload_thumb_image']);
        $item['company-name'] = $ebook['company_name'];
        $item['company-text'] = $ebook['headline'];
        $item['search-href'] = base_url('catalog-search.php?co_name=The%20Electricity%20Forum');
        $item['search-text'] = 'Search FREE Handbooks';

        $this->item = $item;

    }

    public function getItemProperty() {
        return $this->item;
    }

}
