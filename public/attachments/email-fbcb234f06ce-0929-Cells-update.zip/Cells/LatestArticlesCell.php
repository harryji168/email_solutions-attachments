<?php

namespace App\Cells;

use CodeIgniter\View\Cells\Cell;
use App\Models\Content\ArticleModel;

class LatestArticlesCell extends Cell
{
    
    protected $content;
    protected $items;

    protected string $view = 'latest_template';
    
    public function mount() {

        // Process Static Content
        $content = [];
        $content['header-light'] = "Latest ";
        $content['header-bold'] = "Electricity Articles";

        // Process Database Content
        $itemModel = new ArticleModel();
        $items = $itemModel->fetchArticles();

        if( !empty($items) && is_array($items) ) {
            foreach( $items as $key => $item ) {
                if ($item['primary_channel_id'] === "1" || $item['primary_channel_id'] === "2") {
                    $items[$key]['href'] = $itemModel->setArticleUrl($item['id']);
                } else if ($item['primary_channel_id'] === '4') {
                    $items[$key]['href'] = base_url("renewable-energy/" . $item['meta_file_name']);
                } else {
                    $items[$key]['href'] = base_url($item['meta_file_name']);
                }
                $items[$key]['img-source'] = base_url("uploads/articles/" . $item['image_name']);
                $items[$key]['img-alt'] = 'Article Thumbnail';
                $items[$key]['text'] = $item['head_line'];
            }
        }

        $this->items = $items;
        $this->content = $content;

    }

    public function getItemsProperty() {
        return $this->items;
    }

    public function getContentProperty() {
        return $this->content;
    }   

}
