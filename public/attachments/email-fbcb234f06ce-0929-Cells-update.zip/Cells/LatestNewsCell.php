<?php

namespace App\Cells;

use CodeIgniter\View\Cells\Cell;
use App\Models\Content\NewsModel;

class LatestNewsCell extends Cell
{
    
    protected $content;
    protected $items;

    protected string $view = 'latest_template';
    
    public function mount() {

        // Process Static Content
        $content = [];
        $content['header-light'] = "Latest ";
        $content['header-bold'] = "Electrical Industry News";

        // Process Database Content
        $itemModel = new NewsModel();
        $items = $itemModel->fetchNews(1);
        if( empty($items) ) {
            $items = $itemModel->fetchNews(2);
        }

        if( !empty($items) && is_array($items) ) {
            foreach( $items as $key => $item ) {
                $items[$key]['href'] = base_url("news/" . $item['meta_file_name']);
                $items[$key]['img-source'] = base_url('uploads/news-items/' . $item['image_name']);
                $items[$key]['img-alt'] = 'News Thumbnail';
                $items[$key]['text'] = $item['head_line'];
            }
        }

        /* REVISIT VISITOR TRACKING METHODS
        if (isset($sessionData['sess_user_id'])) {
            $visitorModel->visitorStatDatabase($videoChannelId, $videoCompanyId, $videoId, "video", $sessUserId, $videoUrl);
        } else {
            $visitorModel->visitorStatDatabase($videoChannelId, $videoCompanyId, $videoId, "video", 0, $videoUrl);
        }
        */

        $this->items = $items;
        $this->content = $content;

    }

    public function getItemsProperty() {
        return $this->items;
    }

    public function getContentProperty() {
        return $this->content;
    }  

}
