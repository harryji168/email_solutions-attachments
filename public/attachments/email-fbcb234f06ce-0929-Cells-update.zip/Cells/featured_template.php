<div class="col-md-12 bg-grey no-pad-left no-pad-right feature-box">

    <div class="home-feature"><?=$item['title'];?></div>

    <div class="pop-video-container margin_top20" style="height:150px !important;">

        <a href="<?=$item['href'];?>">

            <div class="module-block text-center pickgradient_video" style="min-height:150px;">

                <img loading="lazy" alt="<?=$item['img-alt'];?>" class="center-block" style="height:150px" src="<?=$item['img-source'];?>" />                

            </div>

        </a>

        <?php if( isset($item['isVideo']) ):?>
            <div class="play_icon_div" style="margin-top: -50%; margin-left: 40%;">
                <a href="<?=$item['href'];?>" class="play-control" style="font-size: 60px;"><i class="fa fa-youtube-play"></i></a>
            </div>
        <?php endif;?>

    </div>

    <div class="caption close-up" style="height:60px;">
        <p style="padding:6px 3px;"><span class="header-bold"><?=$item['company-name'];?></span><br><?=$item['company-text'];?></p>
    </div>

</div>

<div class="close-up pickgradient_video text-center">

    <h6 class="header-light"><a href="<?=$item['search-href'];?>"><span class="orange-accent"><i class="fa fa-search"></i> <?=$item['search-text'];?> </span></a></h6>

</div>