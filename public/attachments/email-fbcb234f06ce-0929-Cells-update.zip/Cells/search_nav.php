<div class="logo_menu_div container-fluid clearfix" style="background-color:#fff;border-bottom-width: 0px; display:block;">

	<div class="hidden-sm hidden-xs col-md-3">
		<!-- Just leaving this here for the format -->
	</div>

	<div class="col-md-3 col-md-push-6">

		<div class="row">
			<div class="col-sm-6 col-xs-12 col-md-12">
				<div style="height:30px;" class="input-group pull-right">
					<input type="text" style="background-color: #fcfcfc;height: 30px !important;border: solid 1px #ddd !important;border-top-left-radius: 3px;border-bottom-left-radius: 3px;box-shadow: none;" placeholder="Search any term, company or product..." name="search" id="full_search_input" value="<?php if(isset($_REQUEST['search'])){ echo urlParameterremoveHyphen($_REQUEST['search']); } ?>" class="form-control" />
					<span class="input-group-btn">
						<button style="background-color:#ddd;height:31px;border-width:0px;" type="button" id="full_search_button" class="btn btn-default"><i style="color:#fff;" class="fa fa-search"></i></button>
					</span>
				</div><!-- /input-group -->
				<span id="full_search_error" style="color:red;margin-left:2%;font-size:12px;display:none"></span>
			</div>
		</div>

	</div>

	<div class="col-md-6 col-md-pull-3 text-center">

		<div class="center-block text-center google_ad_nav" style="padding:8px 0;">
			<?=$banner;?>
		</div>

	</div>

</div>