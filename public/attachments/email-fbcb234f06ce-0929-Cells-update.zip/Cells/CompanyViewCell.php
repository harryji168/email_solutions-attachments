<?php

namespace App\Cells;

use CodeIgniter\View\Cells\Cell;
use App\Models\Partner\CompanyModel;

class CompanyViewCell extends Cell
{
    
    protected $companies;
    
    public function mount() {

        $companyModel = new CompanyModel();

        $companies = $companyModel->fetchCompanies();

        foreach( $companies as $k => $company ) {

            if( $company['cametafilename'] != '' ) {
                $companies[$k]['companyURL'] = $companyModel->getCompanyURL( $company['channel_id'], $company['cametafilename']);
            } else {
                $companies[$k]['companyURL'] = $companyModel->seo_company_url( $company['channel_id'], $company['cametafilename']);
            }


            /**
             * More overwhelming visitor data collection. Too much on one page.
             */

             /*
             if (isset($sessionData['sess_user_id'])) {
                $visitorModel->visitorStatDatabase($companyChannelId, $companyId, $companyId, "company", $sessionData['sess_user_id'], $more);
            } else {
                $visitorModel->visitorStatDatabase($companyChannelId, $companyId, $companyId, "company", 0, $more);
            }
            */

        }

        $this->companies = $companies;

    }

    public function getCompaniesProperty() {
        return $this->companies;
    }   

}
