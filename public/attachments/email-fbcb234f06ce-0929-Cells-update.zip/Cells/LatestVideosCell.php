<?php

namespace App\Cells;

use CodeIgniter\View\Cells\Cell;
use App\Models\Partner\VideoModel;

class LatestVideosCell extends Cell
{
    
    protected $content;
    protected $items;

    protected string $view = 'latest_template';
    
    public function mount() {

        // Process Static Content
        $content = [];
        $content['header-light'] = "LATEST VIDEOS";
        $content['header-bold'] = "Watch And Learn";

        // Process Database Content
        $itemModel = new VideoModel();
        $items = $itemModel->fetchVideos();

        if( !empty($items) && is_array($items) ) {
            foreach( $items as $key => $item ) {
                $items[$key]['href'] = base_url('videos/' . urlParameterAddHyphen($item['company_name']) . '/' . $item['meta_file_name']);
                $items[$key]['img-source'] = base_url("uploads/videos/" . $item['thumbnail_img']);
                $items[$key]['img-alt'] = 'Video Thumbnail';
                $items[$key]['text'] = $item['headline'];
            }
        }

        /* REVISIT VISITOR TRACKING METHODS
        if (isset($sessionData['sess_user_id'])) {
            $visitorModel->visitorStatDatabase($videoChannelId, $videoCompanyId, $videoId, "video", $sessUserId, $videoUrl);
        } else {
            $visitorModel->visitorStatDatabase($videoChannelId, $videoCompanyId, $videoId, "video", 0, $videoUrl);
        }
        */

        $this->items = $items;
        $this->content = $content;

    }

    public function getItemsProperty() {
        return $this->items;
    }

    public function getContentProperty() {
        return $this->content;
    }

}
