<?php

namespace App\Cells;

use CodeIgniter\View\Cells\Cell;
use App\Models\Content\ArticleModel;

class FeaturedArticleCell extends Cell
{
    
    protected $article;
    
    public function mount() {

        $articleModel = new ArticleModel();

        $article = $articleModel->fetchFeatureArticle();

        if ($article['primary_channel_id'] === "1" || $article['primary_channel_id'] === "2") {
            $article['articleURL'] = $articleModel->setArticleUrl($article['id']);
        } else {
            $article['articleURL'] = base_url($article['meta_file_name']);
        }

        $article['articleImage'] = base_url("uploads/articles/" . $article['image_name']);

        $this->article = $article;

    }

    public function getArticleProperty() {
        return $this->article;
    }   

}
