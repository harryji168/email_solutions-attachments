<?php

namespace App\Cells;

use CodeIgniter\View\Cells\Cell;

class SearchNavCell extends Cell
{
    
    protected $banner;
    
    public function mount($currPage, $channelId) {

        /**
         * There are 2 options here:
         * 1. List all the pages in the entire sitemap that use ads in the switch statement, and assign them the appropriate ads.
         * 2. On each indviidual page in the Controller methods, assign the correct ad in a data variable
         * I prefer option 2, so when new pages are added, the Ad is part of the configuration, instead of having to add that new page to this switch case.
         */

        switch($currPage) {
            case 'company.php' :
            case 'ipt.php':
                $this->banner = '';
                break;
            case 'videos-listing.php' :
            case 'video-channels.php' :
            case 'video-companies.php' :
                $this->banner = model('App\Models\Ads\BannerAdsModel')->localAd('video');
                break;
            case 'showcases-listing.php' :
            case 'showcase-channels.php' :
            case 'showcase-companies.php' :
                $this->banner = model('App\Models\Ads\BannerAdsModel')->localAd('showcase');
                break;
            case 'literature-list.php' :
            case 'catalog-search.php' :
            case 'literature.php' :
                $this->banner = model('App\Models\Ads\BannerAdsModel')->localAd('literature');
                break;
            default :
                $this->banner = model('App\Models\Ads\BannerAdsModel')->getBanManProAd();
        }

    }

    public function getBannerProperty() {
        return $this->banner;
    }

    private function getBanManProAd( $currPage = null, $channelId = null ) {

        // We can keep this conditional setup size relevance per zone, but will be replaced with new system

        if( $channelId==strtolower("iep") || $channelId==2 ) {
            if( $currPage=="channels.php" ) {
                if($showBanManAd) {
                    return banmanproIEP728X90();
                }
            } else {
                return banmanproIEP728X90();
            }            
        } else if( $channelId==strtolower("td") || $channelId==1 ) {
            if($currPage=="channels.php") {
                if($showBanManAd)  {
                    return banmanproTD728X90();
                }
            } else {
                return banmanproTD728X90();
            }            
        } else {
            switch($currPage) {
                case 'electrical-training.php' :
                case 'training-course.php' :
                case 'onsite-training.php' :
                case 'electrical-courses-schedule.php' :
                case 'electrical-training-benefits.php' :
                case 'online-electrical-courses.php' :
                case 'electrical-learning.php' :
                case 'ceu-credits.php' :
                case 'trainer.php' :
                case 'all-courses.php' :
                    return banmanproTraining728X90();
                    break;
                default :
                    return banmanproCommon728X90();
            }
        }

    }
   

}
