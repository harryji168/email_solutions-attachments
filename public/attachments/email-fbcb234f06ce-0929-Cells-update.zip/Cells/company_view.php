<div class="container text-center">

    <h2 class="topheadline1 text-center" style="text-align:center !important;font-size:36px;">Latest EF Buyer's Guide Companies</h2>

    <?php foreach($companies as $company):?>

        <div class="col-xs-12 col-sm-4 col-md-2 margin_top10 text-center" style="height: 80px; display: flex; align-items: center; justify-content: center; margin-bottom: 20px; margin-top: 20px;">

            <a href="<?=$company['companyURL'];?>"><img loading="lazy" alt="<?=$company['company_name'];?>" src="<?=base_url('uploads/' . $company['company_logo']);?>" style="width:125px" class="img-responsive" /></a>

        </div>

    <?php endforeach;?>

</div>