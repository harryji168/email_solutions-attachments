<div class="col-md-8 bg-grey no-pad-left">

    <div class="col-xs-12 col-md-6  margin_top10">

        <h5 class="heading51 text-left"><span class="header-bold">FEATURE </span> <span class="header-light">ARTICLE</span></h5>
        <h5 class="heading5 text-left"><span style="color:#999999 !important;"><?=$article['head_line'];?></span></h5>
        <p class="light-dense"><?= substr(strip_tags($article['content']), 0, 290) ?>... <a class="dark-link header-bold" style="color:#000001 !important;" href="<?=$article['articleURL'];?>">READ MORE <span class="orange-accent"><i class="fa fa-caret-right"></i></span></a></p>

    </div>

    <div class="col-xs-12 col-md-6 margin_top35">

        <img loading="lazy" alt="<?=$article['image_alt_tag'];?>" src="<?=$article['articleImage'];?>" class="center-block img-responsive" />

    </div>
</div>